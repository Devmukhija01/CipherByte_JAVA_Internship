package UserManagement;

public class ProfileManager {
    public void updateProfile(User user, String newUsername, String newPassword) {
        user.setUsername(newUsername);
        user.setPassword(newPassword);
    }
}
