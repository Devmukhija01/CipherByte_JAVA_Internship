package UserManagement;

import java.util.HashMap;
import java.util.Map;

public class LoginManager {
    private Map<String, User> users = new HashMap<>();

    public LoginManager() {
        users.put("testuser", new User("testuser", "password123"));
    }

    public boolean login(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return true;
        }
        return false;
    }

    public User getUser(String username) {
        return users.get(username);
    }

    public void updateUser(User user, String oldUsername) {
        users.remove(oldUsername);
        users.put(user.getUsername(), user);  
    }
}
