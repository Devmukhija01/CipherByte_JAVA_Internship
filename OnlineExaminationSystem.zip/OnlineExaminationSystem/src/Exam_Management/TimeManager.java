package Exam_Management;

public class TimeManager implements Runnable {
    private long startTime;
    private long duration;
    private boolean running;

    public TimeManager(long duration) {
        this.duration = duration;
        this.running = false;
    }

    @Override
    public void run() {
        startTimer();
        while (!isTimeUp()) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Time is up!");
    }

    public void startTimer() {
        startTime = System.currentTimeMillis();
        running = true;
    }

    public boolean isTimeUp() {
        if (!running) {
            return false;
        }
        long currentTime = System.currentTimeMillis();
        return (currentTime - startTime) >= duration;
    }

    public long getRemainingTime() {
        if (!running) {
            return duration;
        }
        long currentTime = System.currentTimeMillis();
        return duration - (currentTime - startTime);
    }

    public void displayRemainingTime() {
        long remainingTime = getRemainingTime();
        long minutes = remainingTime / (1000 * 60);
        long seconds = (remainingTime / 1000) % 60;
        System.out.printf("Remaining time: %02d:%02d\n", minutes, seconds);
    }
}
