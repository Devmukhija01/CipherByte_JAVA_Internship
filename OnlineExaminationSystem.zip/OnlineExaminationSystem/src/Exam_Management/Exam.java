package Exam_Management;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Exam {
    private List<Question> questions;
    private Map<Question, Integer> answers;

    public Exam(List<Question> questions) {
        this.questions = questions;
        this.answers = new HashMap<>();
    }

    public void answerQuestion(Question question, int answerIndex) {
        answers.put(question, answerIndex);
    }

    public int calculateScore() {
        int score = 0;
        for (Map.Entry<Question, Integer> entry : answers.entrySet()) {
            if (entry.getValue() == entry.getKey().getCorrectAnswerIndex()) {
                score++;
            }
        }
        return score;
    }
    public List<Question> getQuestions() {
        return questions;
    }

    public Map<Question, Integer> getAnswers() {
        return answers;
    }
}
