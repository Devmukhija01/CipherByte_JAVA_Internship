package sessionmanagement;

import Exam_Management.Exam;
import Exam_Management.TimeManager;
import UserManagement.User;
import UserManagement.ProfileManager;
import UserManagement.LoginManager;

public class SessionManager {
    private User currentUser;
    private Exam currentExam;
    private TimeManager timerManager;
    private ProfileManager profileManager;
    private LoginManager loginManager;

    public SessionManager(LoginManager loginManager) {
        this.profileManager = new ProfileManager();
        this.loginManager = loginManager;
    }

    public void startSession(User user, Exam exam, long duration) {
        this.currentUser = user;
        this.currentExam = exam;
        this.timerManager = new TimeManager(duration);

        Thread timerThread = new Thread(timerManager);
        timerThread.start();

        System.out.println("Exam started. You have " + (duration / 1000) + " seconds to complete the exam.");
    }

    public void endSession() {
        if (timerManager != null && timerManager.isTimeUp()) {
            int score = currentExam.calculateScore();
            System.out.println("Time is up! Your score is: " + score);
        } else if (currentExam != null) {
            int score = currentExam.calculateScore();
            System.out.println("Session ended manually. Your score is: " + score);
        }
        currentExam = null;
    }

    public void logout() {
        if (currentExam != null) {
            endSession();
        }
        currentUser = null;
        System.out.println("Logged out successfully.");
    }

    public void updateProfile(String newUsername, String newPassword) {
        if (currentUser != null) {
            String oldUsername = currentUser.getUsername();
            profileManager.updateProfile(currentUser, newUsername, newPassword);
            loginManager.updateUser(currentUser, oldUsername);
            currentUser = loginManager.getUser(newUsername);  // Refresh currentUser with updated details
        } else {
            System.out.println("No user logged in. Profile update failed.");
        }
    }

    public void displayRemainingTime() {
        if (timerManager != null) {
            timerManager.displayRemainingTime();
        }
    }
    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public Exam getCurrentExam() {
        return currentExam;
    }

    public TimeManager getTimerManager() {
        return timerManager;
    }
}
