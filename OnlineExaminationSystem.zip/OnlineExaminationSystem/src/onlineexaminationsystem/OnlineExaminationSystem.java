package onlineexaminationsystem;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import UserManagement.LoginManager;
import UserManagement.User;
import Exam_Management.Exam;
import Exam_Management.Question;
import sessionmanagement.SessionManager;

public class OnlineExaminationSystem {
    public static void main(String[] args) {
        LoginManager loginManager = new LoginManager();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Online Examination System");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.println("Attempting to login with username: " + username + " and password: " + password);
        if (loginManager.login(username, password)) {
            System.out.println("Login successful!");

            User user = loginManager.getUser(username);
            SessionManager sessionManager = new SessionManager(loginManager);
            sessionManager.setCurrentUser(user);

            System.out.print("Do you want to update your profile? (yes/no): ");
            String updateProfileChoice = scanner.nextLine().trim();
            if ("yes".equalsIgnoreCase(updateProfileChoice)) {
                System.out.print("Enter new username: ");
                String newUsername = scanner.nextLine().trim();
                System.out.print("Enter new password: ");
                String newPassword = scanner.nextLine().trim();
                sessionManager.updateProfile(newUsername, newPassword);
                System.out.println("Profile Updated!!");
           
                user = loginManager.getUser(newUsername);
                sessionManager.setCurrentUser(user);
            }

            System.out.print("Do You Want to Take The Quiz? (yes/no): ");
            String quizChoice = scanner.nextLine().trim();
            if("yes".equalsIgnoreCase(quizChoice))
            {
                Question q1 = new Question("What is 2+2?", Arrays.asList("3", "4", "5", "6"), 1);
            Question q2 = new Question("What is the capital of France?", Arrays.asList("London", "Berlin", "Paris", "Rome"), 2);
            List<Question> questions = Arrays.asList(q1, q2);
            Exam exam = new Exam(questions);
            
            sessionManager.startSession(user, exam, 60000);
            int currentQuestionIndex = 0;
            while (currentQuestionIndex < questions.size()) {
                Question currentQuestion = questions.get(currentQuestionIndex);
                System.out.println(currentQuestion.getQuestionText());
                List<String> options = currentQuestion.getOptions();
                for (int i = 0; i < options.size(); i++) {
                    System.out.println((i) + ". " + options.get(i));
                }
                sessionManager.displayRemainingTime();
                System.out.print("Your answer (or type 'skip' to skip this question): ");
                String answerInput = scanner.nextLine().trim();

                if ("skip".equalsIgnoreCase(answerInput)) {
                    System.out.println("Question skipped.");
                    currentQuestionIndex++;
                    continue;
                }

                try {
                    int answerIndex = Integer.parseInt(answerInput) - 1;
                    if (answerIndex < 0 || answerIndex >= options.size()) {
                        System.out.println("Invalid answer index. Please try again.");
                        continue;
                    }
                    exam.answerQuestion(currentQuestion, answerIndex);
                    currentQuestionIndex++;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number or 'skip'.");
                }
            }
            sessionManager.endSession();
            sessionManager.logout();
            }
            else
            {
                 sessionManager.logout();
            }
        scanner.close();
    }
    }
}